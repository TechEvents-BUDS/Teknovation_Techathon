

// Toggle between Login and Sign Up forms
function toggleForm() {
    const loginForm = document.getElementById('login-form');
    const signupForm = document.getElementById('signup-form');
    const authTitle = document.getElementById('auth-title');

    if (loginForm.style.display === 'none') {
        loginForm.style.display = 'block';
        signupForm.style.display = 'none';
        authTitle.textContent = 'Login';
    } else {
        loginForm.style.display = 'none';
        signupForm.style.display = 'block';
        authTitle.textContent = 'Sign Up';
    }
}

// Login function
function login() {
    const email = document.getElementById('login-email').value;
    const password = document.getElementById('login-password').value;
    if (!email || !password) {
        alert('Please fill in both the email and password fields.');
        return;
    }
    if (email === 'admin' && password === 'admin') {
        alert('Login successfull!');
        window.location.href = 'main.html';
    } else {
        alert('incorrrect credentials.');
    }

   
}

// Sign Up function
function signup() {
    const email = document.getElementById('signup-email').value;
    const password = document.getElementById('signup-password').value;
    if (!email || !password) {
        alert('Please fill in both the email and password fields.');
        return;
    }

    if (email === 'admin' && password === 'admin') {
        alert('Sign up successful! (Admin user)');
        window.location.href = 'index.html';
    } else {
        alert('Only admin can sign up with these credentials.');
    }
}


// Your Firebase configuration
const firebaseConfig = {
    apiKey: "YOUR_API_KEY",
    authDomain: "YOUR_AUTH_DOMAIN",
    projectId: "YOUR_PROJECT_ID",
    storageBucket: "YOUR_STORAGE_BUCKET",
    messagingSenderId: "YOUR_MESSAGING_SENDER_ID",
    appId: "YOUR_APP_ID"
};

// Initialize Firebase
const app = firebase.initializeApp(firebaseConfig);
const auth = firebase.auth();

// Toggle between Login and Sign Up forms
function toggleForm() {
    const loginForm = document.getElementById('login-form');
    const signupForm = document.getElementById('signup-form');
    const authTitle = document.getElementById('auth-title');

    if (loginForm.style.display === 'none') {
        loginForm.style.display = 'block';
        signupForm.style.display = 'none';
        authTitle.textContent = 'Login';
    } else {
        loginForm.style.display = 'none';
        signupForm.style.display = 'block';
        authTitle.textContent = 'Sign Up';
    }
}

// Login function
function login() {
    const email = document.getElementById('login-email').value;
    const password = document.getElementById('login-password').value;

    // auth.signInWithEmailAndPassword(email, password)
    //     .then((userCredential) => {
    //         alert('Login successful!');
    //         console.log(userCredential.user);
    //     })
    //     .catch((error) => {
    //         alert(error.message);
    //     });
    if(email && password == "admin")
        {
            window.location.href="main.html"
        }
        else{alert("invalid username or password.");}
}

// Sign Up function
function signup() {
    const email = document.getElementById('signup-email').value;
    const password = document.getElementById('signup-password').value;

    // auth.createUserWithEmailAndPassword(email, password)
    //     .then((userCredential) => {
    //         alert('Sign up successful!');
    //         console.log(userCredential.user);
    //     })
    //     .catch((error) => {
    //         alert(error.message);
    //     });
}